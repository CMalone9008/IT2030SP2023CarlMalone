﻿namespace CarlsWatches.Models
{
    public class ProductModel
    {
        public int productId { get; set; }
        public string productName { get; set; } = string.Empty;
        public string productDescription { get; set; } = string.Empty;
        public string productImage { get; set; } = string.Empty;
        public decimal productPrice { get; set; }

    }
}
