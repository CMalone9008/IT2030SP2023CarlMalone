﻿namespace CarlsWatches.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    productId = 1,
                    productName = "Rolex",
                    productDescription = "Model: Explorer 1, Reference#: 114270",
                    productImage = "RolexExp1.jpg",
                    productPrice = 7000
                },
                new ProductModel
                {
                    productId = 2,
                    productName = "Grand Seiko",
                    productDescription = "Model: Elegance, Reference#: SBGW273",
                    productImage = "GrandSeiko.jpg",
                    productPrice = 4800

                },
                new ProductModel
                {
                    productId = 3,
                    productName = "Rolex",
                    productDescription = "Model: Datejust 36, Reference#: 116200",
                    productImage = "RolexDJ36.jpg",
                    productPrice = 7250

                },
                new ProductModel
                {
                    productId = 4,
                    productName = "Omega",
                    productDescription = "Model: Seamaster 300m, Reference#: 210.30.42.20.06.001",
                    productImage = "OmegaSeamaster300mG.jpg",
                    productPrice = 5400
                },
                new ProductModel
                {
                    productId = 5,
                    productName = "Cartier",
                    productDescription = "Model: Santos, Reference#: WSSA0029",
                    productImage = "CartierSantosM.jpg",
                    productPrice = 6800
                },
                new ProductModel
                {
                    productId = 6,
                    productName = "Tag Heuer",
                    productDescription = "Model: Carrera, Rerference#: WAR211B.BA0782",
                    productImage = "THCarrera39.jpg",
                    productPrice = 2800
                }
            };
            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach(ProductModel product in products)
            {
                if(product.productId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
   
