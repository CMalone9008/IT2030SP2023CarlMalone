﻿using System.ComponentModel.DataAnnotations;


namespace CarlsWatches.Models
{
    public class ContactModel
    {
        [Required(ErrorMessage = "Please enter a first name")]
        public string? firstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name")]
        public string? lastName { get; set;}

        [Required(ErrorMessage = "Please enter an address")]
        public string? address { get; set; }

        [Required(ErrorMessage = "Please enter a phone number")]
        public decimal? phone { get; set; }

        [Required(ErrorMessage = "Please enter an email")]
        public string? email { get; set; }

        [Required(ErrorMessage = "Please enter a message")]
        public string? message { get; set; }

    }
}
